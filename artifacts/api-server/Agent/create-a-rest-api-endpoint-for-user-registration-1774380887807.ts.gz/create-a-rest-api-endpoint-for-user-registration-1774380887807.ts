import express, { type Request, type Response } from "express";
import { z } from "zod";
import crypto from "crypto";

/**
 * User registration router (self-contained).
 *
 * Mount example:
 *   app.use("/api", registrationRouter);
 *
 * Endpoints:
 *   POST /users/register
 */
const router = express.Router();

/**
 * Simple in-memory user store (replace with a real database in production).
 */
type UserRecord = {
  id: string;
  email: string;
  username: string;
  passwordHash: string;
  salt: string;
  createdAt: string;
};

const usersByEmail = new Map<string, UserRecord>();
const usersByUsername = new Map<string, UserRecord>();

/**
 * Zod schema for user registration payload.
 */
const RegisterBodySchema = z
  .object({
    email: z.string().trim().toLowerCase().email(),
    username: z
      .string()
      .trim()
      .min(3)
      .max(32)
      .regex(/^[a-zA-Z0-9_]+$/, "Username may contain only letters, numbers, and underscore"),
    password: z
      .string()
      .min(8)
      .max(128)
      .refine((p) => /[a-z]/.test(p), "Password must contain at least one lowercase letter")
      .refine((p) => /[A-Z]/.test(p), "Password must contain at least one uppercase letter")
      .refine((p) => /[0-9]/.test(p), "Password must contain at least one number"),
    displayName: z.string().trim().min(1).max(64).optional(),
  })
  .strict();

/**
 * Hash a password using scrypt.
 * @param password Plaintext password
 * @param salt Random salt (hex)
 * @returns Derived key (hex)
 */
async function hashPassword(password: string, salt: string): Promise<string> {
  const saltBuf = Buffer.from(salt, "hex");
  return await new Promise<string>((resolve, reject) => {
    crypto.scrypt(password, saltBuf, 64, { N: 1 << 15, r: 8, p: 1 }, (err, derivedKey) => {
      if (err) return reject(err);
      resolve(derivedKey.toString("hex"));
    });
  });
}

/**
 * Constant-time compare for secret strings.
 * @param a hex string
 * @param b hex string
 */
function timingSafeEqualHex(a: string, b: string): boolean {
  const aBuf = Buffer.from(a, "hex");
  const bBuf = Buffer.from(b, "hex");
  if (aBuf.length !== bBuf.length) return false;
  return crypto.timingSafeEqual(aBuf, bBuf);
}

/**
 * Generate a cryptographically-secure random ID.
 */
function generateId(): string {
  return crypto.randomUUID();
}

/**
 * Normalize email for lookup (lowercase, trimmed).
 */
function normalizeEmail(email: string): string {
  return email.trim().toLowerCase();
}

/**
 * Normalize username for lookup (trimmed; keep case as provided but enforce uniqueness case-insensitively).
 */
function normalizeUsername(username: string): string {
  return username.trim().toLowerCase();
}

/**
 * Minimal request rate limiting (in-memory, per-IP). Replace with a durable store in production.
 */
type RateLimitEntry = { count: number; resetAt: number };
const RATE_LIMIT_WINDOW_MS = 60_000;
const RATE_LIMIT_MAX = 20;
const rateLimitByIp = new Map<string, RateLimitEntry>();

function getClientIp(req: Request): string {
  const xff = req.headers["x-forwarded-for"];
  if (typeof xff === "string" && xff.length > 0) return xff.split(",")[0].trim();
  if (Array.isArray(xff) && xff.length > 0) return String(xff[0]).split(",")[0].trim();
  return req.ip || "unknown";
}

function isRateLimited(req: Request): { limited: boolean; retryAfterSeconds: number } {
  const ip = getClientIp(req);
  const now = Date.now();
  const existing = rateLimitByIp.get(ip);

  if (!existing || now >= existing.resetAt) {
    rateLimitByIp.set(ip, { count: 1, resetAt: now + RATE_LIMIT_WINDOW_MS });
    return { limited: false, retryAfterSeconds: 0 };
  }

  existing.count += 1;
  rateLimitByIp.set(ip, existing);

  if (existing.count > RATE_LIMIT_MAX) {
    const retryAfterSeconds = Math.max(1, Math.ceil((existing.resetAt - now) / 1000));
    return { limited: true, retryAfterSeconds };
  }

  return { limited: false, retryAfterSeconds: 0 };
}

/**
 * POST /users/register
 *
 * Registers a new user.
 *
 * Request body:
 *  - email: string
 *  - username: string
 *  - password: string
 *  - displayName?: string
 *
 * Responses:
 *  - 201 Created: { id, email, username, createdAt }
 *  - 400 Bad Request: validation errors
 *  - 409 Conflict: email/username already exists
 *  - 429 Too Many Requests: rate limited
 */
router.post("/users/register", async (req: Request, res: Response) => {
  try {
    const rl = isRateLimited(req);
    if (rl.limited) {
      res.setHeader("Retry-After", String(rl.retryAfterSeconds));
      return res.status(429).json({
        error: "too_many_requests",
        message: "Too many registration attempts. Please try again later.",
      });
    }

    const parsed = RegisterBodySchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({
        error: "validation_error",
        message: "Invalid request body.",
        details: parsed.error.flatten(),
      });
    }

    const { email, username, password } = parsed.data;
    const emailKey = normalizeEmail(email);
    const usernameKey = normalizeUsername(username);

    const existingByEmail = usersByEmail.get(emailKey);
    if (existingByEmail) {
      // Avoid user enumeration in real systems; here we return a conflict explicitly.
      return res.status(409).json({
        error: "conflict",
        message: "Email is already registered.",
      });
    }

    const existingByUsername = usersByUsername.get(usernameKey);
    if (existingByUsername) {
      return res.status(409).json({
        error: "conflict",
        message: "Username is already taken.",
      });
    }

    const salt = crypto.randomBytes(16).toString("hex");
    const passwordHash = await hashPassword(password, salt);

    // Defensive check (demonstrates constant-time compare usage; not strictly necessary here).
    if (!timingSafeEqualHex(passwordHash, await hashPassword(password, salt))) {
      throw new Error("Password hashing verification failed");
    }

    const user: UserRecord = {
      id: generateId(),
      email: emailKey,
      username: username.trim(),
      passwordHash,
      salt,
      createdAt: new Date().toISOString(),
    };

    usersByEmail.set(emailKey, user);
    usersByUsername.set(usernameKey, user);

    return res.status(201).json({
      id: user.id,
      email: user.email,
      username: user.username,
      createdAt: user.createdAt,
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Unknown error";
    return res.status(500).json({
      error: "internal_server_error",
      message,
    });
  }
});

export default router;