import { Router, type Request, type Response, type NextFunction } from "express";
import { z } from "zod";

/**
 * Geospatial Insight API Router
 *
 * Provides endpoints for:
 * - reverse geocoding (mocked)
 * - point-in-polygon test
 * - distance (haversine) between points
 * - clustering of points into grid cells
 * - bounding box & centroid for a set of points
 *
 * This module is self-contained and does not require external services.
 */
const router = Router();

/** WGS84 latitude bounds */
const LAT_MIN = -90;
const LAT_MAX = 90;
/** WGS84 longitude bounds */
const LON_MIN = -180;
const LON_MAX = 180;

const GeoPointSchema = z.object({
  lat: z.number().min(LAT_MIN).max(LAT_MAX),
  lon: z.number().min(LON_MIN).max(LON_MAX),
});

const PolygonSchema = z
  .object({
    // Array of points. Can be open or closed; we will close it if needed.
    coordinates: z
      .array(GeoPointSchema)
      .min(3, "Polygon must have at least 3 points"),
  })
  .refine(
    (v) => {
      // Ensure not all points are identical / degenerate
      const unique = new Set(v.coordinates.map((p) => `${p.lat},${p.lon}`));
      return unique.size >= 3;
    },
    { message: "Polygon must contain at least 3 distinct points" },
  );

const ReverseGeocodeBodySchema = z.object({
  point: GeoPointSchema,
});

const DistanceBodySchema = z.object({
  from: GeoPointSchema,
  to: GeoPointSchema,
  unit: z.enum(["meters", "kilometers", "miles"]).default("meters"),
});

const PointInPolygonBodySchema = z.object({
  point: GeoPointSchema,
  polygon: PolygonSchema,
  // If true, count points on boundary as inside.
  includeBoundary: z.boolean().default(true),
});

const ClusterGridBodySchema = z.object({
  points: z.array(GeoPointSchema).max(20000, "Too many points; max is 20000"),
  // Grid cell size in degrees; typical: 0.01 ~ 1.0
  cellSizeDegrees: z.number().positive().max(10).default(0.1),
});

const SummaryBodySchema = z.object({
  points: z.array(GeoPointSchema).min(1).max(200000, "Too many points; max is 200000"),
});

type GeoPoint = z.infer<typeof GeoPointSchema>;

/**
 * Create an HTTP error with status.
 */
class HttpError extends Error {
  status: number;
  code: string;

  constructor(status: number, message: string, code = "HTTP_ERROR") {
    super(message);
    this.status = status;
    this.code = code;
  }
}

/**
 * Async handler wrapper to forward errors to Express.
 */
function asyncHandler(
  fn: (req: Request, res: Response, next: NextFunction) => Promise<void>,
) {
  return (req: Request, res: Response, next: NextFunction) => {
    Promise.resolve(fn(req, res, next)).catch(next);
  };
}

/**
 * Validate request body with Zod schema.
 */
function parseBody<T extends z.ZodTypeAny>(schema: T, req: Request): z.infer<T> {
  const result = schema.safeParse(req.body);
  if (!result.success) {
    throw new HttpError(400, "Invalid request body", "VALIDATION_ERROR");
  }
  return result.data;
}

/**
 * Degrees to radians.
 */
function toRad(deg: number): number {
  return (deg * Math.PI) / 180;
}

/**
 * Haversine distance between two points.
 * Returns meters.
 */
function haversineMeters(a: GeoPoint, b: GeoPoint): number {
  const R = 6371008.8; // mean Earth radius in meters
  const dLat = toRad(b.lat - a.lat);
  const dLon = toRad(b.lon - a.lon);
  const lat1 = toRad(a.lat);
  const lat2 = toRad(b.lat);

  const sinDLat = Math.sin(dLat / 2);
  const sinDLon = Math.sin(dLon / 2);

  const h =
    sinDLat * sinDLat +
    Math.cos(lat1) * Math.cos(lat2) * (sinDLon * sinDLon);

  return 2 * R * Math.asin(Math.min(1, Math.sqrt(h)));
}

/**
 * Close polygon ring if needed (last != first).
 */
function closeRing(coords: GeoPoint[]): GeoPoint[] {
  if (coords.length === 0) return coords;
  const first = coords[0];
  const last = coords[coords.length - 1];
  if (first.lat === last.lat && first.lon === last.lon) return coords;
  return [...coords, { ...first }];
}

/**
 * Check if point is on segment (with tolerance in degrees).
 */
function pointOnSegment(p: GeoPoint, a: GeoPoint, b: GeoPoint, tol = 1e-12): boolean {
  // Convert to 2D (lon, lat)
  const px = p.lon;
  const py = p.lat;
  const ax = a.lon;
  const ay = a.lat;
  const bx = b.lon;
  const by = b.lat;

  // Cross product magnitude for colinearity
  const cross = (px - ax) * (by - ay) - (py - ay) * (bx - ax);
  if (Math.abs(cross) > tol) return false;

  // Dot product to check within segment bounds
  const dot = (px - ax) * (bx - ax) + (py - ay) * (by - ay);
  if (dot < -tol) return false;

  const lenSq = (bx - ax) * (bx - ax) + (by - ay) * (by - ay);
  if (dot - lenSq > tol) return false;

  return true;
}

/**
 * Ray casting point-in-polygon test on lon/lat plane.
 * Note: This is planar; for small areas it's acceptable; for large regions use spherical algorithms.
 */
function pointInPolygon(
  point: GeoPoint,
  polygon: GeoPoint[],
  includeBoundary: boolean,
): boolean {
  const ring = closeRing(polygon);
  if (ring.length < 4) return false; // 3 + closing point

  // Boundary check
  for (let i = 0; i < ring.length - 1; i++) {
    if (pointOnSegment(point, ring[i], ring[i + 1])) {
      return includeBoundary;
    }
  }

  // Ray casting: count intersections with ray to +x (lon increasing)
  let inside = false;
  const x = point.lon;
  const y = point.lat;

  for (let i = 0, j = ring.length - 2; i < ring.length - 1; j = i++) {
    const xi = ring[i].lon;
    const yi = ring[i].lat;
    const xj = ring[j].lon;
    const yj = ring[j].lat;

    const intersect =
      yi > y !== yj > y &&
      x < ((xj - xi) * (y - yi)) / (yj - yi + 0) + xi;

    if (intersect) inside = !inside;
  }

  return inside;
}

/**
 * Compute bounding box for points.
 */
function boundingBox(points: GeoPoint[]) {
  let minLat = Infinity;
  let minLon = Infinity;
  let maxLat = -Infinity;
  let maxLon = -Infinity;

  for (const p of points) {
    if (p.lat < minLat) minLat = p.lat;
    if (p.lon < minLon) minLon = p.lon;
    if (p.lat > maxLat) maxLat = p.lat;
    if (p.lon > maxLon) maxLon = p.lon;
  }

  return { minLat, minLon, maxLat, maxLon };
}

/**
 * Compute centroid (simple average) for points.
 * Note: This is not a spherical centroid; for tight clusters it is acceptable.
 */
function centroid(points: GeoPoint[]): GeoPoint {
  let sumLat = 0;
  let sumLon = 0;
  for (const p of points) {
    sumLat += p.lat;
    sumLon += p.lon;
  }
  return { lat: sumLat / points.length, lon: sumLon / points.length };
}

/**
 * Grid cluster points into degree-based cells.
 */
function clusterGrid(points: GeoPoint[], cellSizeDegrees: number) {
  const clusters = new Map<
    string,
    { key: string; cell: { x: number; y: number }; count: number; bbox: ReturnType<typeof boundingBox>; centroid: GeoPoint }
  >();

  // two-pass for per-cell centroid: accumulate sums
  const acc = new Map<
    string,
    { count: number; sumLat: number; sumLon: number; minLat: number; minLon: number; maxLat: number; maxLon: number; x: number; y: number }
  >();

  for (const p of points) {
    const x = Math.floor((p.lon - LON_MIN) / cellSizeDegrees);
    const y = Math.floor((p.lat - LAT_MIN) / cellSizeDegrees);
    const key = `${x}:${y}`;

    const prev = acc.get(key);
    if (!prev) {
      acc.set(key, {
        count: 1,
        sumLat: p.lat,
        sumLon: p.lon,
        minLat: p.lat,
        minLon: p.lon,
        maxLat: p.lat,
        maxLon: p.lon,
        x,
        y,
      });
    } else {
      prev.count += 1;
      prev.sumLat += p.lat;
      prev.sumLon += p.lon;
      if (p.lat < prev.minLat) prev.minLat = p.lat;
      if (p.lon < prev.minLon) prev.minLon = p.lon;
      if (p.lat > prev.maxLat) prev.maxLat = p.lat;
      if (p.lon > prev.maxLon) prev.maxLon = p.lon;
    }
  }

  for (const [key, v] of acc.entries()) {
    clusters.set(key, {
      key,
      cell: { x: v.x, y: v.y },
      count: v.count,
      bbox: { minLat: v.minLat, minLon: v.minLon, maxLat: v.maxLat, maxLon: v.maxLon },
      centroid: { lat: v.sumLat / v.count, lon: v.sumLon / v.count },
    });
  }

  // Sort by count desc
  const list = Array.from(clusters.values()).sort((a, b) => b.count - a.count);
  return list;
}

/**
 * @route GET /health
 * @description Health check
 */
router.get(
  "/health",
  asyncHandler(async (_req, res) => {
    res.status(200).json({ ok: true, service: "geospatial-insight-api" });
  }),
);

/**
 * @route POST /insights/distance
 * @description Compute haversine distance between two points
 */
router.post(
  "/insights/distance",
  asyncHandler(async (req, res) => {
    try {
      const body = parseBody(DistanceBodySchema, req);
      const meters = haversineMeters(body.from, body.to);

      let value = meters;
      if (body.unit === "kilometers") value = meters / 1000;
      if (body.unit === "miles") value = meters / 1609.344;

      res.status(200).json({
        unit: body.unit,
        value,
        meters,
        from: body.from,
        to: body.to,
      });
    } catch (err) {
      if (err instanceof HttpError) {
        res.status(err.status).json({ error: err.message, code: err.code });
        return;
      }
      throw err;
    }
  }),
);

/**
 * @route POST /insights/point-in-polygon
 * @description Determine whether a point lies inside a polygon
 */
router.post(
  "/insights/point-in-polygon",
  asyncHandler(async (req, res) => {
    try {
      const body = parseBody(PointInPolygonBodySchema, req);
      const ring = body.polygon.coordinates;
      const inside = pointInPolygon(body.point, ring, body.includeBoundary);

      res.status(200).json({
        inside,
        includeBoundary: body.includeBoundary,
        point: body.point,
        polygon: {
          coordinatesCount: ring.length,
          closed: ring.length > 0 && ring[0].lat === ring[ring.length - 1].lat && ring[0].lon === ring[ring.length - 1].lon,
        },
      });
    } catch (err) {
      if (err instanceof HttpError) {
        res.status(err.status).json({ error: err.message, code: err.code });
        return;
      }
      throw err;
    }
  }),
);

/**
 * @route POST /insights/cluster-grid
 * @description Cluster points into grid cells (degree-based)
 */
router.post(
  "/insights/cluster-grid",
  asyncHandler(async (req, res) => {
    try {
      const body = parseBody(ClusterGridBodySchema, req);
      const clusters = clusterGrid(body.points, body.cellSizeDegrees);

      res.status(200).json({
        cellSizeDegrees: body.cellSizeDegrees,
        points: body.points.length,
        clusters: clusters.length,
        topClusters: clusters.slice(0, 500), // safety cap for response size
      });
    } catch (err) {
      if (err instanceof HttpError) {
        res.status(err.status).json({ error: err.message, code: err.code });
        return;
      }
      throw err;
    }
  }),
);

/**
 * @route POST /insights/summary
 * @description Compute bounding box and centroid for a set of points
 */
router.post(
  "/insights/summary",
  asyncHandler(async (req, res) => {
    try {
      const body = parseBody(SummaryBodySchema, req);
      const bbox = boundingBox(body.points);
      const center = centroid(body.points);

      res.status(200).json({
        points: body.points.length,
        bbox,
        centroid: center,
      });
    } catch (err) {
      if (err instanceof HttpError) {
        res.status(err.status).json({ error: err.message, code: err.code });
        return;
      }
      throw err;
    }
  }),
);

/**
 * @route POST /insights/reverse-geocode
 * @description Reverse geocode a point (mock implementation; returns coarse region labels)
 */
router.post(
  "/insights/reverse-geocode",
  asyncHandler(async (req, res) => {
    try {
      const body = parseBody(ReverseGeocodeBodySchema, req);
      const { lat, lon } = body.point;

      // Coarse mock "insight" labels based on lat/lon bands
      const hemisphereNS = lat >= 0 ? "N" : "S";
      const hemisphereEW = lon >= 0 ? "E" : "W";
      const latBand = Math.min(89, Math.floor(Math.abs(lat) / 10) * 10);
      const lonBand = Math.min(179, Math.floor(Math.abs(lon) / 10) * 10);

      res.status(200).json({
        point: body.point,
        insight: {
          label: `Hemisphere ${hemisphereNS}${hemisphereEW} • Bands ${latBand}-${latBand + 10}° lat, ${lonBand}-${lonBand + 10}° lon`,
          hemisphere: { ns: hemisphereNS, ew: hemisphereEW },
          bands: {
            lat: { from: lat >= 0 ? latBand : -latBand - 10, to: lat >= 0 ? latBand + 10 : -latBand },
            lon: { from: lon >= 0 ? lonBand : -lonBand - 10, to: lon >= 0 ? lonBand + 10 : -lonBand },
          },
        },
        note: "Reverse geocoding is mocked. Integrate a provider (e.g., Nominatim/Google) for real addresses.",
      });
    } catch (err) {
      if (err instanceof HttpError) {
        res.status(err.status).json({ error: err.message, code: err.code });
        return;
      }
      throw err;
    }
  }),
);

/**
 * @route GET /
 * @description API index
 */
router.get(
  "/",
  asyncHandler(async (_req, res) => {
    res.status(200).json({
      service: "geospatial-insight-api",
      endpoints: [
        { method: "GET", path: "/health" },
        { method: "POST", path: "/insights/distance" },
        { method: "POST", path: "/insights/point-in-polygon" },
        { method: "POST", path: "/insights/cluster-grid" },
        { method: "POST", path: "/insights/summary" },
        { method: "POST", path: "/insights/reverse-geocode" },
      ],
    });
  }),
);

/**
 * Error handler for this router.
 * Must be mounted after routes: app.use("/geo", router)
 */
router.use((err: unknown, _req: Request, res: Response, _next: NextFunction) => {
  const fallback = { error: "Internal Server Error", code: "INTERNAL_ERROR" };

  if (err instanceof HttpError) {
    res.status(err.status).json({ error: err.message, code: err.code });
    return;
  }

  if (err instanceof z.ZodError) {
    res.status(400).json({ error: "Invalid request body", code: "VALIDATION_ERROR" });
    return;
  }

  // Handle common body-parser / JSON parse failures (Express may throw SyntaxError)
  if (err instanceof SyntaxError) {
    res.status(400).json({ error: "Malformed JSON", code: "MALFORMED_JSON" });
    return;
  }

  res.status(500).json(fallback);
});

export default router;