import express, { type Request, type Response, type NextFunction } from "express";

/**
 * Express router providing a simple healthcheck endpoint.
 */
const router = express.Router();

/**
 * GET /ping
 *
 * Simple liveness endpoint.
 *
 * @route GET /ping
 * @returns 200 - JSON payload indicating service is alive
 */
router.get(
  "/ping",
  async (_req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      res.status(200).json({ ok: true, message: "pong" });
    } catch (err) {
      next(err);
    }
  }
);

export default router;