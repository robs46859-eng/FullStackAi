import express, { type Request, type Response } from "express";
import { z } from "zod";

/**
 * User record stored in memory.
 */
type User = {
  id: string;
  email: string;
  phone: string;
  createdAt: string;
  updatedAt: string;
};

/**
 * Error response payload.
 */
type ErrorResponse = {
  error: {
    message: string;
    details?: unknown;
  };
};

/**
 * Success response payload for list endpoints.
 */
type ListResponse<T> = {
  data: T[];
};

/**
 * Success response payload for single-resource endpoints.
 */
type ItemResponse<T> = {
  data: T;
};

const router = express.Router();

/**
 * In-memory storage (demo/standalone). Replace with a database in production.
 */
const usersById = new Map<string, User>();
const idByEmail = new Map<string, string>();

/**
 * Generates a reasonably unique ID without external dependencies.
 */
function generateId(): string {
  // Combines timestamp and randomness; good enough for in-memory usage.
  return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
}

/**
 * Normalize email for consistent lookups.
 */
function normalizeEmail(email: string): string {
  return email.trim().toLowerCase();
}

/**
 * Best-effort phone normalization (keeps digits and leading '+').
 * This is not a full E.164 validator, but enforces sane input.
 */
function normalizePhone(phone: string): string {
  const trimmed = phone.trim();
  const hasPlus = trimmed.startsWith("+");
  const digits = trimmed.replace(/[^\d]/g, "");
  return hasPlus ? `+${digits}` : digits;
}

/**
 * Zod schemas.
 */
const UserCreateSchema = z.object({
  email: z.string().email().transform(normalizeEmail),
  phone: z
    .string()
    .min(7)
    .max(32)
    .transform(normalizePhone)
    .refine((v) => /^\+?\d{7,15}$/.test(v), {
      message: "phone must be 7-15 digits, optionally starting with +",
    }),
});

const UserUpdateSchema = z
  .object({
    email: z.string().email().transform(normalizeEmail).optional(),
    phone: z
      .string()
      .min(7)
      .max(32)
      .transform(normalizePhone)
      .refine((v) => /^\+?\d{7,15}$/.test(v), {
        message: "phone must be 7-15 digits, optionally starting with +",
      })
      .optional(),
  })
  .refine((obj) => Object.keys(obj).length > 0, {
    message: "At least one field must be provided",
  });

const IdParamSchema = z.object({
  id: z.string().min(1),
});

/**
 * Utility to send consistent errors.
 */
function sendError(res: Response, status: number, message: string, details?: unknown): void {
  const payload: ErrorResponse = { error: { message, details } };
  res.status(status).json(payload);
}

/**
 * Health endpoint.
 */
router.get("/health", async (_req: Request, res: Response) => {
  res.status(200).json({ ok: true });
});

/**
 * Create a user.
 * POST /users
 */
router.post("/users", async (req: Request, res: Response) => {
  try {
    const parsed = UserCreateSchema.safeParse(req.body);
    if (!parsed.success) {
      return sendError(res, 400, "Validation failed", parsed.error.flatten());
    }

    const { email, phone } = parsed.data;

    if (idByEmail.has(email)) {
      return sendError(res, 409, "User with this email already exists");
    }

    const now = new Date().toISOString();
    const user: User = {
      id: generateId(),
      email,
      phone,
      createdAt: now,
      updatedAt: now,
    };

    usersById.set(user.id, user);
    idByEmail.set(user.email, user.id);

    const response: ItemResponse<User> = { data: user };
    return res.status(201).json(response);
  } catch (err) {
    return sendError(res, 500, "Internal server error");
  }
});

/**
 * List users.
 * GET /users
 */
router.get("/users", async (_req: Request, res: Response) => {
  try {
    const data = Array.from(usersById.values()).sort((a, b) => a.createdAt.localeCompare(b.createdAt));
    const response: ListResponse<User> = { data };
    return res.status(200).json(response);
  } catch (_err) {
    return sendError(res, 500, "Internal server error");
  }
});

/**
 * Get user by ID.
 * GET /users/:id
 */
router.get("/users/:id", async (req: Request, res: Response) => {
  try {
    const parsedParams = IdParamSchema.safeParse(req.params);
    if (!parsedParams.success) {
      return sendError(res, 400, "Validation failed", parsedParams.error.flatten());
    }

    const user = usersById.get(parsedParams.data.id);
    if (!user) {
      return sendError(res, 404, "User not found");
    }

    const response: ItemResponse<User> = { data: user };
    return res.status(200).json(response);
  } catch (_err) {
    return sendError(res, 500, "Internal server error");
  }
});

/**
 * Update user by ID.
 * PATCH /users/:id
 */
router.patch("/users/:id", async (req: Request, res: Response) => {
  try {
    const parsedParams = IdParamSchema.safeParse(req.params);
    if (!parsedParams.success) {
      return sendError(res, 400, "Validation failed", parsedParams.error.flatten());
    }

    const parsedBody = UserUpdateSchema.safeParse(req.body);
    if (!parsedBody.success) {
      return sendError(res, 400, "Validation failed", parsedBody.error.flatten());
    }

    const id = parsedParams.data.id;
    const existing = usersById.get(id);
    if (!existing) {
      return sendError(res, 404, "User not found");
    }

    const updates = parsedBody.data;
    let nextEmail = existing.email;

    if (updates.email && updates.email !== existing.email) {
      if (idByEmail.has(updates.email)) {
        return sendError(res, 409, "User with this email already exists");
      }
      // Update email index
      idByEmail.delete(existing.email);
      idByEmail.set(updates.email, id);
      nextEmail = updates.email;
    }

    const updated: User = {
      ...existing,
      email: nextEmail,
      phone: updates.phone ?? existing.phone,
      updatedAt: new Date().toISOString(),
    };

    usersById.set(id, updated);

    const response: ItemResponse<User> = { data: updated };
    return res.status(200).json(response);
  } catch (_err) {
    return sendError(res, 500, "Internal server error");
  }
});

/**
 * Delete user by ID.
 * DELETE /users/:id
 */
router.delete("/users/:id", async (req: Request, res: Response) => {
  try {
    const parsedParams = IdParamSchema.safeParse(req.params);
    if (!parsedParams.success) {
      return sendError(res, 400, "Validation failed", parsedParams.error.flatten());
    }

    const id = parsedParams.data.id;
    const existing = usersById.get(id);
    if (!existing) {
      return sendError(res, 404, "User not found");
    }

    usersById.delete(id);
    idByEmail.delete(existing.email);

    return res.status(204).send();
  } catch (_err) {
    return sendError(res, 500, "Internal server error");
  }
});

/**
 * Lookup user by email.
 * GET /users/by-email/:email
 */
router.get("/users/by-email/:email", async (req: Request, res: Response) => {
  try {
    const EmailParamSchema = z.object({
      email: z.string().email().transform(normalizeEmail),
    });

    const parsedParams = EmailParamSchema.safeParse(req.params);
    if (!parsedParams.success) {
      return sendError(res, 400, "Validation failed", parsedParams.error.flatten());
    }

    const id = idByEmail.get(parsedParams.data.email);
    if (!id) {
      return sendError(res, 404, "User not found");
    }

    const user = usersById.get(id);
    if (!user) {
      // Inconsistent state; repair index.
      idByEmail.delete(parsedParams.data.email);
      return sendError(res, 404, "User not found");
    }

    const response: ItemResponse<User> = { data: user };
    return res.status(200).json(response);
  } catch (_err) {
    return sendError(res, 500, "Internal server error");
  }
});

export default router;